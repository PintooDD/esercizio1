let cart = [];
let total = 0;


function addToCart(productName, price) {
  const cartItems = document.getElementById('cartItems');
  const emptyMessage = document.getElementById('emptyCartMessage');


  if (emptyMessage) {
    emptyMessage.remove();
  }

 
  cart.push({ name: productName, price });
  total += price;
  updateCartDisplay();
}


function updateCartDisplay() {
  const cartItems = document.getElementById('cartItems');
  cartItems.innerHTML = ''; 

  cart.forEach((item, index) => {
    const cartItem = document.createElement('div');
    cartItem.className = 'flex justify-between items-center bg-gray-100 p-2 rounded';
    cartItem.innerHTML = `
      <span>${item.name} - €${item.price.toFixed(2)}</span>
      <button onclick="removeFromCart(${index})" class="btn btn-error">Rimuovi</button>
    `;
    cartItems.appendChild(cartItem);
  });

  document.getElementById('cartTotal').textContent = `Totale: €${total.toFixed(2)}`;
}


function removeFromCart(index) {
  total -= cart[index].price; 
  cart.splice(index, 1); 
  updateCartDisplay();


  if (cart.length === 0) {
    const cartItems = document.getElementById('cartItems');
    const emptyMessage = document.createElement('p');
    emptyMessage.id = 'emptyCartMessage';
    emptyMessage.textContent = 'Il carrello è vuoto.';
    cartItems.appendChild(emptyMessage);
  }
}


function checkout() {
  if (cart.length > 0) {
    document.getElementById('paymentModal').classList.remove('hidden');
  } else {
    alert('Il carrello è vuoto!');
  }
}


function closeModal() {
  document.getElementById('paymentModal').classList.add('hidden');
}
